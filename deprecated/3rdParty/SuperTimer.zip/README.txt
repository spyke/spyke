TSuperTimer 1.0.3 * 25 August 1998
==================================

TDigits is a VCL component for Delphi 2, 3 & 4 and C++Builder 1 & 3.
Copyright (C) 1996-1998, by Jan Goyvaerts.

Visit http://www.ping.be/jg/ for more excellent VCL components
by the same author.

See SuperTimer.txt for more information on how to use TSuperTimer.


Delphi 1 installation
=====================

TSuperTimer is a 32-bit component.
Delphi 1 is therefore not supported.


Delphi 2 installation
=====================

1. Unzip SuperTimer2.zip into the directory of your choice. You will probably
   want to use an existing directory as Delphi's Library Path can be no
   longer than 127 characters.
2. Launch Delphi 2 if it isn't already running.
3. Choose Component|Install... from the menu, click the Add button, click the
   Browse button and select the file SuperTimer.dcu in the TSuperTimer directory
   created in step 1.
4. Click Ok to recompile the component library.
5. Have fun!


Delphi 3 installation
=====================

1. Unzip SuperTimer3.zip into the directory of your choice.
2. Run Delphi 3 if it is not yet running.
3. Pick Component|Install component from the menu. Specify SuperTimer.dcu as 
   the component unit name. Select the package of your choice and hit OK.
4. Have fun!


Delphi 4 installation
=====================

1. Unzip SuperTimer4.zip into the directory of your choice.
2. Run Delphi 4 if it is not yet running.
3. Pick Component|Install component from the menu. Specify SuperTimer.dcu as 
   the component unit name. Select the package of your choice and hit OK.
4. Have fun!


C++Builder 1 installation
=========================

1. Unzip SuperTimerC.zip into the directory of your choice. You will probably
   want to use an existing directory as C++Builder's Library Path can be no
   longer than 127 characters.
2. Launch C++Builder if it isn't already running.
3. Choose Component|Install... from the menu, click the Add button, 
   click the Browse button and select the file SuperTimer.obj in the 
   TSuperTimer directory created in step 1.
4. Click Ok to recompile the component library.
5. Have fun!


C++Builder 3 installation
=========================

1. Unzip SuperTimerC3.zip into the directory of your choice. You will probably
   want to use an existing directory as C++Builder's Library Path can be no
   longer than 127 characters.
2. Launch C++Builder 3 if it isn't already running.
3. Pick Component|Install component from the menu. Specify SuperTimer.obj as 
   the component unit name. Select the package of your choice and hit OK.
4. Have fun!


Installation note
=================

If Delphi complains it cannot find something.pas or something.dcu, this means that 
the Library Path is too long. Put your components together in just a few directories
and shorten the Library Path.
You do not need the source code to be able to use this component.


Source code
===========

The TSuperTimer distribution files do not include any source code.
However, some people wish not to use any components to which they do not have
the source code.

Therefore, you can buy the source code. This will cost you US$10. There are
no royalties or what so ever.

Since I do not have the time to do this myself, orders are handled for me
by PsL (Public software Library).

PsL is a service that handles credit card orders (and credit card orders only)
for shareware programmers. Of course, this is not a free service. This means
that the costs of handling the order are added to the registration fee.

After you have placed your order, PsL will notify me and then I will send the
registered verrsion of TSuperTimer to you. This way you are sure you get the
latest version.

The best way to place your order, is to use PsL's secure registration page
on the web. You can find the link on my home page at 
http://www.ping.be/jg/register.shtml
Note that the source code to all the other components I wrote can be bought 
there too. Since you will be charged a $3 handling fee for each order, you may
want to check first if you would want to buy any additional components. If you
order them at the same time, you will have to pay only one handling fee.

Alternatively, you can contact PsL by
 * e-mail: 30396@pslweb.com
 * fax: +1-713-524-6398 (please print your text, no handwriting)

Note that the above numbers are for credit card orders only.
Any questions about the status of the shipment of the order,
registration options, product details, technical support, volume discounts,
dealer pricing, site licenses, etc, must be directed to the author at
jg@ping.be

When placing your order, please mention the following details:
 * What you wish to buy: 
   TSuperTimer source code for US$13, PsL product ID: 30396
 * Your name
 * Your postal address
 * Your email address
 * Credit card type and number, expiration date and the name on the card 
   if it differs from your name mentioned above.